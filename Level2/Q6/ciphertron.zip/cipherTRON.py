from binascii import hexlify
from gmpy2 import *
import math
import os
import sys

if sys.version_info < (3, 9):
    math.gcd = gcd
    math.lcm = lcm

_DEBUG = False


MATRIX_OF_LEADERSHIP = open('flag.txt').read().strip()
CYBERTRONIAN_MESSAGE = mpz(hexlify(MATRIX_OF_LEADERSHIP.encode()), 16)

ALLSPARK = mpz(hexlify(os.urandom(32)).decode(), 16)
CYBERTRONIAN_STATE = random_state(ALLSPARK)


def forge_prime(state, bits):
    return next_prime(mpz_urandomb(state, bits) | (1 << (bits - 1)))

def construct_autobot_prime(state, bits, smoothness=16):
    prime_autobot = mpz(2)
    prime_factors = [prime_autobot]
    while prime_autobot.bit_length() < bits - 2 * smoothness:
        factor = forge_prime(state, smoothness)
        prime_factors.append(factor)
        prime_autobot *= factor

    remaining_bits = (bits - prime_autobot.bit_length()) // 2

    while True:
        prime_one = forge_prime(state, remaining_bits)
        prime_two = forge_prime(state, remaining_bits)
        temp_prime = prime_autobot * prime_one * prime_two
        if temp_prime.bit_length() < bits:
            remaining_bits += 1
            continue
        if temp_prime.bit_length() > bits:
            remaining_bits -= 1
            continue
        if is_prime(temp_prime + 1):
            prime_factors.append(prime_one)
            prime_factors.append(prime_two)
            prime_autobot = temp_prime + 1
            break

    prime_factors.sort()
    return (prime_autobot, prime_factors)
# The Leadership of the Autobots
PRIME_DIRECTIVE = 0x10001
while True:
    AUTOBOT_PRIME, autobot_factors = construct_autobot_prime(CYBERTRONIAN_STATE, 1024, 16)
    if len(autobot_factors) != len(set(autobot_factors)):
        continue

    DECEPTICON_PRIME, decepticon_factors = construct_autobot_prime(CYBERTRONIAN_STATE, 1024, 17)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        # thErE's nothing hErE.
    if len(decepticon_factors) != len(set(decepticon_factors)):
        continue

    cosmic_factors = autobot_factors + decepticon_factors
    if PRIME_DIRECTIVE not in cosmic_factors:
        break

if _DEBUG:
    import sys
    sys.stderr.write(f'AUTOBOT_PRIME = {AUTOBOT_PRIME.digits(16)}\n\n')
    sys.stderr.write(f'Autobot Factors = [\n')
    for factor in autobot_factors:
        sys.stderr.write(f'    {factor.digits(16)},\n')
    sys.stderr.write(f']\n\n')

    sys.stderr.write(f'DECEPTICON_PRIME = {DECEPTICON_PRIME.digits(16)}\n\n')
    sys.stderr.write(f'Decepticon Factors = [\n')
    for factor in decepticon_factors:
        sys.stderr.write(f'    {factor.digits(16)},\n')
    sys.stderr.write(f']\n\n')


CYBERTRON_MODULUS = AUTOBOT_PRIME * DECEPTICON_PRIME


PRIME_WISDOM = math.lcm(AUTOBOT_PRIME - 1, DECEPTICON_PRIME - 1)
OPTIMUS_KEY = pow(PRIME_DIRECTIVE, -1, PRIME_WISDOM)


CYBERTRONIAN_CIPHERTEXT = pow(CYBERTRONIAN_MESSAGE, PRIME_DIRECTIVE, CYBERTRON_MODULUS)


print(f'CYBERTRON_MODULUS (n): {CYBERTRON_MODULUS.digits(16)}')
print(f'CYBERTRONIAN_CIPHERTEXT (c): {CYBERTRONIAN_CIPHERTEXT.digits(16)}')
